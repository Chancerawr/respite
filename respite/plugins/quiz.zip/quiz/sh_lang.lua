nut.lang.Add("quiz_title", "issues")
nut.lang.Add("quiz_notification", "If the answers to the questions are incorrect, you will be disconnected from the server.")
nut.lang.Add("quiz_submit", "Submit Answers")
